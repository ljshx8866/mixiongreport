import { BadRequestException, Body, Controller, Get, Post, Req } from '@nestjs/common';
import { AuthService, Public, authUser } from './auth';

const text = (value: unknown, name: string) => {
  if (typeof value !== 'string' || !value.trim()) throw new BadRequestException(`${name} is required`);
  return value.trim();
};

@Controller('api/auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Public()
  @Post('login') login(@Body() body: Record<string, unknown>) {
    return this.auth.login(text(body.mobile, 'mobile'), text(body.password, 'password'));
  }

  @Public()
  @Post('wechat') wechat(@Body() body: Record<string, unknown>) {
    return this.auth.wechatLogin(
      text(body.code, 'code'),
      typeof body.mobile === 'string' ? body.mobile.trim() : undefined,
      typeof body.password === 'string' ? body.password : undefined,
    );
  }

  // Requires the existing server API key and is available only before the first administrator exists.
  @Post('bootstrap') bootstrap(@Body() body: Record<string, unknown>) {
    return this.auth.bootstrap(text(body.name, 'name'), text(body.mobile, 'mobile'), text(body.password, 'password'));
  }

  @Get('me') me(@Req() request: { user?: unknown }) { return authUser(request as never); }
}
