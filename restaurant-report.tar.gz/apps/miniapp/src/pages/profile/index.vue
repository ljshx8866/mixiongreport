<script setup lang="ts">
import { reactive, ref } from 'vue'
import { loginWithWechat } from '../../utils/wechat'
const form = reactive({ mobile: '', password: '' }); const error = ref(''); const user = ref<any>(uni.getStorageSync('user'))
async function bind() { error.value = ''; try { await loginWithWechat(form); user.value = uni.getStorageSync('user'); uni.showToast({ title: '绑定成功' }) } catch (cause) { error.value = cause instanceof Error ? cause.message : '绑定失败' } }
function logout() { uni.removeStorageSync('accessToken'); uni.removeStorageSync('user'); user.value = null }
</script>
<template><view v-if="user" class="card"><text class="label">我的</text><text class="value">{{ user.role }}</text><text class="label">已分配门店：{{ user.storeIds?.join('、') || '全部门店' }}</text><view class="button" style="margin-top:24rpx" @click="logout">退出登录</view></view><view v-else class="card"><text class="value">绑定门店账号</text><text class="label">首次微信登录需要验证一次已有账号。</text><view class="field"><text>手机号</text><input v-model="form.mobile" type="number"/></view><view class="field"><text>密码</text><input v-model="form.password" password/></view><text v-if="error" style="color:#dc2626">{{error}}</text><view class="button" @click="bind">绑定并登录</view></view></template>
